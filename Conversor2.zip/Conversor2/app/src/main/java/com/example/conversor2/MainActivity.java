package com.example.conversor2;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import com.example.conversor2.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Referências para os componentes da UI
        EditText etDolar = findViewById(R.id.etDolar);
        Button btnConverter = findViewById(R.id.btnConverter);
        TextView tvResultado = findViewById(R.id.tvResultado);

        // Taxa de conversão de dólar para real
        final double taxaDeConversao = 5.86; // Taxa fixa, mas você pode adicionar uma API para obter taxas dinâmicas.

        // Lógica do botão para conversão
        btnConverter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String valorDolarString = etDolar.getText().toString();

                // Converter de Dólar para Real
                if (!valorDolarString.isEmpty()) {
                    double valorDolar = Double.parseDouble(valorDolarString);
                    double resultado = valorDolar * taxaDeConversao;
                    tvResultado.setText(String.format("Resultado: R$ %.2f", resultado));
                } else {
                    tvResultado.setText("Por favor, insira um valor válido.");
                }
            }
        });
    }
}
